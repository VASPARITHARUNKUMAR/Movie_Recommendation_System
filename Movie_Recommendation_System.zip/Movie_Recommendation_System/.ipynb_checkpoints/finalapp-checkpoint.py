import streamlit as st
import pandas as pd
import pickle

# Load all saved files
with open("tfidf_vectorizer.pkl", "rb") as f:
    tfidf = pickle.load(f)

with open("kmeans_model.pkl", "rb") as f:
    kmeans = pickle.load(f)

movies = pd.read_pickle("movies_with_clusters.pkl")

st.title("🎬 Movie Recommender (KMeans Based)")

movie_list = movies['title'].sort_values().unique().tolist()
selected_movie = st.selectbox("Choose a movie:", movie_list)

if st.button("Recommend Similar Movies"):
    if selected_movie in movies['title'].values:
        cluster_id = movies[movies['title'] == selected_movie]['cluster'].values[0]
        similar_movies = movies[(movies['cluster'] == cluster_id) & (movies['title'] != selected_movie)]["title"].tolist()

        st.success(f"Movies similar to '{selected_movie}':")
        for movie in similar_movies[:10]:
            st.write("🎥", movie)
    else:
        st.warning("Movie not found in dataset.")
